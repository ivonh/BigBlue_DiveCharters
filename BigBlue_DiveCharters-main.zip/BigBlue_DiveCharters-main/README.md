# BigBlue_DiveCharters
This is an assessment for my school, I welcome suggestions but as you will see its pretty simple program
